app_name = "repair_management"
app_title = "Repair Management"
app_publisher = "Chirayut D."
app_description = "Return Repair Item to Supplier and Accept Repair Item"
app_email = "chang@eakthai.com"
app_license = "mit"

# Apps
# ------------------

# required_apps = []

# Each item in the list will be shown as an app in the apps page
# add_to_apps_screen = [
# 	{
# 		"name": "repair_management",
# 		"logo": "/assets/repair_management/logo.png",
# 		"title": "Repair Management",
# 		"route": "/repair_management",
# 		"has_permission": "repair_management.api.permission.has_app_permission"
# 	}
# ]

# Includes in <head>
# ------------------

# include js, css files in header of desk.html
#app_include_css = "/assets/repair_management/css/print_jpg_button.css"
#app_include_js = "/assets/repair_management/js/print_btn1.js"
app_include_js = [
	"https://maps.googleapis.com/maps/api/js?key=AIzaSyAnAQeOunGXOEO_fXa1tvQbeFaVjJKIgBM&libraries=marker"
]

# include js, css files in header of web template
# web_include_css = "/assets/repair_management/css/repair_management.css"
# web_include_js = "/assets/repair_management/js/repair_management.js"
web_include_js = ["test_vue.bundle.js"]

# include custom scss in every website theme (without file extension ".scss")
# website_theme_scss = "repair_management/public/scss/website"

# include js, css files in header of web form
# webform_include_js = {"doctype": "public/js/doctype.js"}
# webform_include_css = {"doctype": "public/css/doctype.css"}

# include js in page
# page_js = {"page" : "public/js/file.js"}
page_js = {
    "print": "public/js/print_btn_custom.js"
}

# include js in doctype views
# doctype_js = {"doctype" : "public/js/doctype.js"}
# doctype_list_js = {"doctype" : "public/js/doctype_list.js"}
# doctype_tree_js = {"doctype" : "public/js/doctype_tree.js"}
# doctype_calendar_js = {"doctype" : "public/js/doctype_calendar.js"}
doctype_js = {
    "Customer": "public/js/customer_heatmap.js"
}


# Svg Icons
# ------------------
# include app icons in desk
#app_include_icons = "repair_management/public/icons.svg"
app_include_icons = [
     "repair_management/icons/line-icons.svg",
     "repair_management/icons/31-fa-icons.svg"
]

# Home Pages
# ----------

# application home page (will override Website Settings)
# home_page = "login"

# website user home page (by Role)
# role_home_page = {
# 	"Role": "home_page"
# }

# Generators
# ----------

# automatically create page for each record of this doctype
# website_generators = ["Web Page"]

# Jinja
# ----------

# add methods and filters to jinja environment
# jinja = {
# 	"methods": "repair_management.utils.jinja_methods",
# 	"filters": "repair_management.utils.jinja_filters"
# }

jinja = {
    "methods": [
        "repair_management.utils.qr.get_qr_code"
    ]
}

# Installation
# ------------

# before_install = "repair_management.install.before_install"
# after_install = "repair_management.install.after_install"

# Uninstallation
# ------------

# before_uninstall = "repair_management.uninstall.before_uninstall"
# after_uninstall = "repair_management.uninstall.after_uninstall"

# Integration Setup
# ------------------
# To set up dependencies/integrations with other apps
# Name of the app being installed is passed as an argument

# before_app_install = "repair_management.utils.before_app_install"
# after_app_install = "repair_management.utils.after_app_install"

# Integration Cleanup
# -------------------
# To clean up dependencies/integrations with other apps
# Name of the app being uninstalled is passed as an argument

# before_app_uninstall = "repair_management.utils.before_app_uninstall"
# after_app_uninstall = "repair_management.utils.after_app_uninstall"

# Desk Notifications
# ------------------
# See frappe.core.notifications.get_notification_config

# notification_config = "repair_management.notifications.get_notification_config"

# Permissions
# -----------
# Permissions evaluated in scripted ways

# permission_query_conditions = {
# 	"Event": "frappe.desk.doctype.event.event.get_permission_query_conditions",
# }
#
# has_permission = {
# 	"Event": "frappe.desk.doctype.event.event.has_permission",
# }

# DocType Class
# ---------------
# Override standard doctype classes

# override_doctype_class = {
# 	"ToDo": "custom_app.overrides.CustomToDo"
# }

# Document Events
# ---------------
# Hook on document methods and events

# doc_events = {
# 	"*": {
# 		"on_update": "method",
# 		"on_cancel": "method",
# 		"on_trash": "method"
# 	}
# }

# Scheduled Tasks
# ---------------

# scheduler_events = {
# 	"all": [
# 		"repair_management.tasks.all"
# 	],
# 	"daily": [
# 		"repair_management.tasks.daily"
# 	],
# 	"hourly": [
# 		"repair_management.tasks.hourly"
# 	],
# 	"weekly": [
# 		"repair_management.tasks.weekly"
# 	],
# 	"monthly": [
# 		"repair_management.tasks.monthly"
# 	],
# }

# Testing
# -------

# before_tests = "repair_management.install.before_tests"

# Overriding Methods
# ------------------------------
#
# override_whitelisted_methods = {
# 	"frappe.desk.doctype.event.event.get_events": "repair_management.event.get_events"
# }
#
# each overriding function accepts a `data` argument;
# generated from the base implementation of the doctype dashboard,
# along with any modifications made in other Frappe apps
# override_doctype_dashboards = {
# 	"Task": "repair_management.task.get_dashboard_data"
# }

# exempt linked doctypes from being automatically cancelled
#
# auto_cancel_exempted_doctypes = ["Auto Repeat"]

# Ignore links to specified DocTypes when deleting documents
# -----------------------------------------------------------

# ignore_links_on_delete = ["Communication", "ToDo"]

# Request Events
# ----------------
# before_request = ["repair_management.utils.before_request"]
# after_request = ["repair_management.utils.after_request"]

# Job Events
# ----------
# before_job = ["repair_management.utils.before_job"]
# after_job = ["repair_management.utils.after_job"]

# User Data Protection
# --------------------

# user_data_fields = [
# 	{
# 		"doctype": "{doctype_1}",
# 		"filter_by": "{filter_by}",
# 		"redact_fields": ["{field_1}", "{field_2}"],
# 		"partial": 1,
# 	},
# 	{
# 		"doctype": "{doctype_2}",
# 		"filter_by": "{filter_by}",
# 		"partial": 1,
# 	},
# 	{
# 		"doctype": "{doctype_3}",
# 		"strict": False,
# 	},
# 	{
# 		"doctype": "{doctype_4}"
# 	}
# ]

# Authentication and authorization
# --------------------------------

# auth_hooks = [
# 	"repair_management.auth.validate"
# ]

# Automatically update python controller files with type annotations for this app.
# export_python_type_annotations = True

# default_log_clearing_doctypes = {
# 	"Logging DocType Name": 30  # days to retain logs
# }

doctype_list_js = {
	"Repair List": "public/js/repair_list_list.js"
}

#doctypr_js = {
#	"Repair List": "public/js/repair_list.js"
#}


def boot_session(bootinfo):
    bootinfo.google_maps_api_key = "AIzaSyAnAQeOunGXOEO_fXa1tvQbeFaVjJKIgBM"

# Custom Fields
#fixtures = ["Custom Field"]
fixtures = [
    {
        "dt": "Custom Field",
        "filters": [
            [
                "name",
                "in",
                [
                    # Address Map
                    "Address-custom_map",
                    "Address-custom_latitude",
                    "Address-custom_longtitude",
                    "Address-custom_map_html",
		    # Auto Generate T&C to Sales Order
                    "Customer-tc_name",
		    # Serial No. Keep Record
                    "Stock Entry-custom_serial_no_text",
		    # Delivery Note Reference
                    "Delivery Note-custom_payment_date",
                    "Delivery Note-custom_section_break_ci1mq",
                    "Delivery Note-custom_refer_customer",
                    "Delivery Note-custom_customer_name",
		    # Sales Order Map
                    "Sales Order-custom_map",
                    "Sales Order-custom_latitude",
                    "Sales Order-custom_longitude",
                    "Sales Order-custom_map_html",
                ],
            ]
        ],
    }
]

# BEGIN ADDITIONAL SALARY PAYMENT
# Added by additional_salary_payment_v15 installer.

doctype_js = globals().get("doctype_js") or {}
doctype_js["Additional Salary"] = "public/js/additional_salary_payment.js"

doc_events = globals().get("doc_events") or {}


def _asp_add_doc_event(doctype, event, handler):
    handlers = doc_events.setdefault(doctype, {})
    current = handlers.get(event)
    if not current:
        handlers[event] = handler
    elif isinstance(current, (list, tuple)):
        if handler not in current:
            handlers[event] = list(current) + [handler]
    elif current != handler:
        handlers[event] = [current, handler]


_asp_add_doc_event(
    "Additional Salary",
    "before_cancel",
    "repair_management.additional_salary_payment.events.before_cancel_additional_salary",
)
_asp_add_doc_event(
    "Payment Entry",
    "validate",
    "repair_management.additional_salary_payment.events.validate_payment_entry",
)
_asp_add_doc_event(
    "Payment Entry",
    "on_submit",
    "repair_management.additional_salary_payment.events.on_submit_payment_entry",
)
_asp_add_doc_event(
    "Payment Entry",
    "on_cancel",
    "repair_management.additional_salary_payment.events.on_cancel_payment_entry",
)
_asp_add_doc_event(
    "Payment Entry",
    "on_trash",
    "repair_management.additional_salary_payment.events.on_trash_payment_entry",
)

_asp_add_doc_event(
    "Payment Entry",
    "before_cancel",
    "repair_management.additional_salary_payment.events.before_cancel_payment_entry",
)

_after_migrate_handler = "repair_management.additional_salary_payment.setup.install"
_current_after_migrate = globals().get("after_migrate")
if not _current_after_migrate:
    after_migrate = _after_migrate_handler
elif isinstance(_current_after_migrate, (list, tuple)):
    after_migrate = list(_current_after_migrate)
    if _after_migrate_handler not in after_migrate:
        after_migrate.append(_after_migrate_handler)
elif _current_after_migrate != _after_migrate_handler:
    after_migrate = [_current_after_migrate, _after_migrate_handler]
# END ADDITIONAL SALARY PAYMENT

# BEGIN SALARY SLIP PAYMENT
doctype_js["Salary Slip"] = "public/js/salary_slip_payment.js"

_asp_add_doc_event(
    "Salary Slip",
    "before_cancel",
    "repair_management.additional_salary_payment.events.before_cancel_salary_slip",
)
_asp_add_doc_event(
    "Payment Entry",
    "validate",
    "repair_management.additional_salary_payment.events.validate_salary_slip_payment_entry",
)
_asp_add_doc_event(
    "Payment Entry",
    "on_submit",
    "repair_management.additional_salary_payment.events.on_submit_salary_slip_payment",
)
_asp_add_doc_event(
    "Payment Entry",
    "on_cancel",
    "repair_management.additional_salary_payment.events.on_cancel_salary_slip_payment",
)

# END SALARY SLIP PAYMENT

# --- LINE POD dashboard overrides (managed by repair_management_line_pod_v0.2) ---
_pod_dashboard_overrides = {
    "Sales Order": "repair_management.overrides.pod_dashboards.sales_order_dashboard",
    "Delivery Note": "repair_management.overrides.pod_dashboards.delivery_note_dashboard",
}
try:
    override_doctype_dashboards.update(_pod_dashboard_overrides)
except NameError:
    override_doctype_dashboards = _pod_dashboard_overrides

_pod_route_rules = [
    {"from_route": "/line/app/delivery-confirm", "to_route": "line/app/delivery_confirm"},
]
try:
    website_route_rules.extend(_pod_route_rules)
except NameError:
    website_route_rules = _pod_route_rules
# --- END LINE POD dashboard overrides ---

# BEGIN CORE PATCH REAPPLY (google_redirect_base_url / public_form_link_base_url)
# bench update overwrites the frappe core files these patches edit; re-apply
# them on every migrate so they survive a core update. See
# repair_management/patches/reapply_core_patches.py.
_core_patch_reapply_handler = "repair_management.patches.reapply_core_patches.after_migrate"
_current_after_migrate = globals().get("after_migrate")
if not _current_after_migrate:
    after_migrate = _core_patch_reapply_handler
elif isinstance(_current_after_migrate, (list, tuple)):
    after_migrate = list(_current_after_migrate)
    if _core_patch_reapply_handler not in after_migrate:
        after_migrate.append(_core_patch_reapply_handler)
elif _current_after_migrate != _core_patch_reapply_handler:
    after_migrate = [_current_after_migrate, _core_patch_reapply_handler]
# END CORE PATCH REAPPLY
