# Design tokens

frappe-ui ships a Tailwind preset with **semantic** color tokens. Use these instead of the raw palette (`gray-500`, `blue-700`, …). Tokens auto-flip in dark mode (`[data-theme="dark"]`).

## Color tokens

Three semantic categories — each takes a color + numeric step. Higher = stronger contrast.

### `text-ink-*` (foreground / text & icons)

`base | gray-1..9 | {red,green,amber,blue,cyan,pink,violet,orange,purple,teal,yellow}-1..10 | blue-link`

- `text-ink-gray-9` — primary text (headings, body).
- `text-ink-gray-7` — secondary text.
- `text-ink-gray-5` / `gray-4` — tertiary / placeholder.
- `text-ink-blue-link` — links.
- `text-ink-red-6` — destructive / error text.
- `text-ink-green-6` — success text.

### `bg-surface-*` (backgrounds)

`base | gray-1..10 | {red,green,amber,blue,cyan,pink,violet,orange,purple,teal,yellow}-1..10 | sidebar | elevation-1..3`

- `bg-surface-base` — primary page background.
- `bg-surface-gray-1` / `gray-2` — subtle / hover surface (cards, hovered rows).
- `bg-surface-gray-3` — pressed state.
- `bg-surface-sidebar` — sidebar/toolbar background.
- `bg-surface-elevation-2` — dialog body background.
- `bg-surface-elevation-3` — selected row.
- `bg-surface-red-2` / `green-2` / `amber-2` / `blue-2` — tinted banners.

### `border-outline-*` (borders & rings)

`base | gray-1..9 | {red,green,amber,blue,cyan,pink,violet,orange,purple,teal,yellow}-1..10 | elevation-1..2`

- `border-outline-gray-1` / `gray-2` — default borders.
- Focus rings are automatic: a global `:focus-visible` outline (`--focus-outline-default`) covers every focusable element — never add your own. Retheme with `focus-visible:focus-ring-red` (or `-green`/`-blue`), suppress with `focus-visible:outline-none`.
- `border-outline-red-3` / `green-2` — error / success borders.

Never reach for `text-gray-900`, `bg-white`, `border-gray-200` — they don't track the theme.

## Typography

`font-family` is `InterVar` by default. The preset ships **two parallel scales** with the same pixel sizes but different line-heights:

- `text-*` — tight (`line-height: 1.15`). For **single-line labels**: headings, button text, badges, table cells, stat values, "2h ago" timestamps.
- `text-p-*` — loose (`line-height: 1.5–1.6`). For **multi-line / descriptive text**: paragraphs, descriptions, helper text, anything that may wrap.

Pick the wrong one and copy looks cramped (multi-line text in `text-*`) or floppy (one-line labels in `text-p-*`).

| Class                       | Size  | Use                                     |
|-----------------------------|-------|-----------------------------------------|
| `text-2xs` / `text-p-2xs`   | 11px  | Micro-labels, badges / tiny captions    |
| `text-xs` / `text-p-xs`     | 12px  | Captions, meta / multi-line meta        |
| `text-sm` / `text-p-sm`     | 13px  | Secondary labels / secondary paragraphs |
| `text-base` / `text-p-base` | 14px  | Body labels / body paragraphs (default) |
| `text-md` / `text-p-md`     | 15px  | Dense section labels / compact intro    |
| `text-lg` / `text-p-lg`     | 16px  | Section subheads / long-form intro      |
| `text-xl` / `text-p-xl`     | 17px  | Card / panel titles / lead paragraphs   |
| `text-2xl`                  | 18px  | Page titles                             |
| `text-3xl`                  | 20px  | Prominent page titles                   |
| `text-4xl`+                 | 24px+ | Marketing / hero only                   |

**Heuristic:** if the element is `<p>`, a description below a label, a feed entry that wraps, or helper text — use `text-p-*`. If it's `<h*>`, a `<Button>`/`<Badge>` label, a one-line meta row like "Updated 2h ago", or a stat value — use `text-*`.

All have tuned letter-spacing — don't override unless you know why.

**Never uppercase headers.** Don't apply `uppercase` (or `tracking-wider` to fake all-caps) to headings, section titles, table-column headers, or labels. Frappe UIs use sentence case — write "Recent activity", not "RECENT ACTIVITY". Distinguish a header by size/weight/color (`text-ink-gray-5` + `text-sm` for a quiet section label), not by capitalization.

## Radius

| Class            | px    | Use                            |
|------------------|-------|--------------------------------|
| `rounded-none`   | 0     | Flush edges                    |
| `rounded-1`      | 4     | Tags, small chips              |
| `rounded-4`      | 8     | Inputs, buttons, list items (default) |
| `rounded-5`      | 10    | Cards                          |
| `rounded-6`      | 12    | Dialogs, larger surfaces       |
| `rounded-7`      | 16    | Hero panels                    |
| `rounded-8`      | 20    | Marketing surfaces             |
| `rounded-full`   | pill  | Avatars, status dots, pill badges |

The full scale is `rounded-0` through `rounded-9` (see `spec/foundations.md`).
The table lists the steps you will actually reach for.

## Shadow

| Class         | Use                                  |
|---------------|--------------------------------------|
| `shadow-sm`   | Cards on white                       |
| `shadow`      | Default (inputs on focus)            |
| `shadow-md`   | Popovers, dropdowns                  |
| `shadow-lg`   | Dialogs                              |
| `shadow-xl`   | Floating panels                      |
| `shadow-2xl`  | Hero overlays                        |

## Spacing

Use Tailwind's spacing scale. The canonical rhythms (gutters, stacks, content widths) live in [DESIGN.md](DESIGN.md) → Geometry.

## Dark mode

Toggle by setting `[data-theme="dark"]` on `<html>`. All semantic tokens flip automatically. Test dark mode for every new screen — don't hand-craft `dark:` variants if a semantic token already covers it.

## Custom CSS hooks

When you must style a frappe-ui component beyond its prop surface, target its `data-slot` / `data-state` attributes (not internal classes):

```css
[data-slot="trigger"][data-state="open"] { box-shadow: ... }
[data-slot="item"][data-disabled] { opacity: .5 }
```

Never use class-injection props (`triggerClass`, `contentClass`) — they don't exist on frappe-ui components by design.
